from django.shortcuts import redirect,render, reverse
from django.http import HttpResponse, HttpResponseRedirect

import json

EARTH_RADIUS=6378
TIME_REFRESH = 6000000


def getcollection(req):
    import pymongo
    db = pymongo.MongoClient("mongodb://bigmms:bigmms1413b@140.138.145.77:27017")
    if(req == 'record'):
        return db['open']['record']
    else:
        return db['open']['contact']

def get_record():
    collection = getcollection('record')

    daily = [0,0,0,0,0,0,0]
    total = [0,0,0,0,0,0,0]

    from datetime import datetime
    get_time = datetime.now().strftime('%Y%m%d')

    for tamp in collection.find():
        if tamp["emotion"]==0:
            #marker.append({'time':tamp['TIME'],'addr':[float(tamp['LAT']), float(tamp['LON'])],'icon': {'url': '/static/img/0.png', 'scaledSize': [48, 48]}})
            total[0] += 1
            if float(get_time) - tamp['time'] < 1.0:
                daily[0] += 1
        elif tamp["emotion"]==1:
            #marker.append({'time':tamp['time'],'addr':[float(tamp['LAT']), float(tamp['LON'])],'icon': {'url': '/static/img/1.png', 'scaledSize': [48, 48]}})
            total[1] += 1
            if float(get_time) - tamp['time'] < 1.0:
                daily[1] += 1
        elif tamp["emotion"]==2:
            #marker.append({'time':tamp['TIME'],'addr':[float(tamp['LAT']), float(tamp['LON'])],'icon': {'url': '/static/img/2.png', 'scaledSize': [48, 48]}})
            total[2] += 1
            if float(get_time) - tamp['time'] < 1.0:
                daily[2] += 1
        elif tamp["emotion"]==3:
            #marker.append({'time':tamp['TIME'],'addr':[float(tamp['LAT']), float(tamp['LON'])],'icon': {'url': '/static/img/3.png', 'scaledSize': [48, 48]}})
            total[3] += 1
            if float(get_time) - tamp['time'] < 1.0:
                daily[3] += 1
        elif tamp["emotion"]==4:
            #marker.append({'time':tamp['TIME'],'addr':[float(tamp['LAT']), float(tamp['LON'])],'icon': {'url': '/static/img/4.png', 'scaledSize': [48, 48]}})
            total[4] += 1
            if float(get_time) - tamp['time'] < 1.0:
                daily[4] += 1
        elif tamp["emotion"]==5:
            #marker.append({'time':tamp['TIME'],'addr':[float(tamp['LAT']), float(tamp['LON'])],'icon': {'url': '/static/img/5.png', 'scaledSize': [48, 48]}})
            total[5] += 1
            if float(get_time) - tamp['time'] < 1.0:
                daily[5] += 1
        elif tamp["emotion"]==6:
            #marker.append({'time':tamp['TIME'],'addr':[float(tamp['LAT']), float(tamp['LON'])],'icon': {'url': '/static/img/6.png', 'scaledSize': [48, 48]}})
            total[6] += 1
            if float(get_time) - tamp['time'] < 1.0:
                daily[6] += 1

    return daily, total

def getvoting(request):
    daily, total = get_record()
    data2 = daily
    for i in total:
        data2.append(i)
    #data1 = json.dumps(daily)
    data = json.dumps(data2)
    response = HttpResponse()
    #response.write(data1)
    response.write(data)
    return response

def getchat(request):
    data2 = []
    print("getchat")
    db = getcollection('getchat')
    temp = int(db.find()[0]['time'])
    str_t = "[" + str(temp) + "]"

    data2.append(str_t)
    data2.append("\n")
    print(data2)

    for d in db.find():
        if(int(d['time']) != int(temp)):
            temp = int(d['time'])
            data2.append("\n")
            data2.append('[' + str(temp) + ']')
            data2.append("\n")

        data2.append("&nbsp&nbsp" + d["msg"])   #"&nbsp&nbsp&nbsp&nbsp&nbsp"
        data2.append("\n")


    data = json.dumps(data2)
    response = HttpResponse()
    response.write(data)
    return response

def summary(request):
    if(contact(request)):
        return redirect('/') #no cookies
    return render(request, 'summary.html', {'time_refresh': TIME_REFRESH})

def contact(request):
    msg = []

    from datetime import datetime
    get_time = datetime.now().strftime('%Y%m%d')

    if(request.GET.get('mybtn')):
        msg.append(request.GET.get('suggest'))
        print("contact us msg!!")
        print(msg)
        collection = getcollection('contact')
        new_msg = {"time" : int(get_time), "msg" : msg[0]}
        collection.insert_one(new_msg).inserted_id
        return True
    return False
