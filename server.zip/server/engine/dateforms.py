from django import forms

class TimeForm(forms.Form):
        begindate = forms.DateField()
        begintime = forms.DateTimeField(widget=forms.TextInput(attrs={'type':'date'}))
        enddate = forms.DateField()
        endtime = forms.DateTimeField(widget=forms.TextInput(attrs={'type':'date'}))

        def __init__(self, *args, **kwargs):
                super(TimeForm, self).__init__(*args, **kwargs)
                self.fields['begindate'].label = "開始日期"
                self.fields['begintime'].label = "開始時間"
                self.fields['enddate'].label = "結束日期"
                self.fields['enddate'].label = "結束時間"