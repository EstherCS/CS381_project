# -*- coding: utf-8 -*-
from __future__ import unicode_literals

from django.db import models
from django.utils import timezone
from django.contrib.auth.models import User
'''
# Create your models here.
class Account(models.Model):
    author = models.ForeignKey(User)
    pw = models.CharField(max_length=20)


class Mark(models.Model):
    author = models.ForeignKey(User)
    latitude = models.CharField(max_length=50)
    longitude = models.CharField(max_length=50)
    date = models.CharField(max_length=50)
    label = models.CharField(max_length=1)
'''